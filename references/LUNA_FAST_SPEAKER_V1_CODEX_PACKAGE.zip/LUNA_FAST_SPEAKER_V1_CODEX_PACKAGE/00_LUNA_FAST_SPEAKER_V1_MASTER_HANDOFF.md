# Luna FAST Speaker v1 — Codex Development Handoff

**Document status:** Implementation specification / user-approved requirements  
**Primary goal:** Build a Windows desktop listening/debug tool that keeps the current Luna FAST synthesis behavior intact, keeps Luna resident in memory, begins speaker playback from the first completed phrase, and makes large-scale human listening QA fast enough to discover pronunciation/prosody/splitting defects and send reproducible fix requests to Codex.

---

## 0. Authoritative inputs and precedence

Before any implementation work, read these files from beginning to end.

1. `luna-narration` skill / project reference — highest authority for Luna voice identity, engine, reference, synthesis parameters, phrase-splitting constraints, prosody rules, production behavior, and rule-evolution protocol.
2. This document — authoritative for FAST Speaker v1 product behavior and UX.
3. Existing repository code and tests — authoritative for the actual current FAST implementation paths and APIs after S00 repo audit.
4. Approved reports from prior implementation stages.

If this document conflicts with the Luna narration skill on voice identity or production behavior, **the Luna narration skill wins**.

### Production invariants — absolutely frozen

FAST Speaker v1 must not change or substitute any of the following:

- Engine: **Chatterbox Multilingual V3**
- Voice reference: **Candidate B only**
- Reference WAV and its identity/hash
- Fixed Luna synthesis parameters:
  - exaggeration `0.5`
  - cfg `0.5`
  - temperature `0.72`
  - repetition_penalty `1.2`
  - min_p `0.05`
  - top_p `1.0`
  - language_id `ko`
- Existing Luna production prosody targets/gates
- Existing production best-of-N behavior and pin mechanism
- Existing production pipeline entrypoint and production outputs
- Existing frozen project audio/cache unless explicitly approved

Do not replace Chatterbox with XTTS, Qwen, neural TTS, or any other engine.

### FAST v1 baseline invariant

The user explicitly chose: **current FAST synthesis behavior stays unchanged in v1.**

The purpose of v1 is not to improve FAST naturalness yet. It is to change the execution architecture so the current FAST result can be listened to rapidly and repeatedly.

S00 must locate and document the actual current FAST code path. Do not assume a filename or implementation from this handoff.

---

# 1. Why this program exists

The first and most important reason for Luna FAST Speaker v1 is:

> The user wants to run as many sentences as possible, listen continuously, detect strange pronunciation / intonation / phrase splitting / pace problems by ear, and immediately give Codex a precise, reproducible correction request.

Therefore this is **not merely a TTS demo app** and not merely a low-latency speaker.

It is a combined:

- resident Luna FAST speaker,
- large-scale listening QA console,
- issue capture tool,
- regression/retest tool,
- Codex handoff generator.

The normal path must remain fast. Deeper analysis is allowed to pause the listening flow after the user marks an issue.

---

# 2. Scope of v1

## 2.1 In scope

- Windows desktop app
- Python + Tkinter UI
- Same Windows PC/environment currently used to generate Luna FAST audio
- Model automatically loads on app startup and remains resident
- Candidate B remains resident with the model/conditioning as supported by the current implementation
- Multi-sentence and paragraph input
- `Ctrl+Enter` and `Speak` button
- Windows default audio output device only
- First phrase playback as soon as that phrase is ready
- Later phrases generated while previous audio is playing when technically possible
- No normal WAV saving
- TTFA / phrase generation time / audio duration / RTF metrics on screen
- Manual input mode
- Batch listening mode
- Stop, Pause, Continue, replay-last-phrase, replay-current-sentence
- Issue capture from recent 3 phrases
- Issue categories
- Detailed pronunciation-error fields
- Issue-only WAV/MD/JSON evidence saving
- Codex fix-request text generation + clipboard copy
- Retest flow and version history
- Hot reload of approved FAST-test rules where safe
- Full Luna worker restart without closing UI
- Session/test list persistence and crash recovery
- TXT/MD import

## 2.2 Out of scope

- Automatic Codex API/CLI invocation from inside the app
- Automatic code modification
- New TTS engine
- New Luna voice reference
- Production rule promotion without explicit user approval
- Voice naturalness improvements beyond preserving current FAST behavior
- Speaker-device picker
- Normal full-session WAV archive
- Real-time microphone conversation
- LLM integration/streaming text generation
- Network API server
- Packaging as a polished commercial installer unless trivial after core acceptance

Those may be later versions.

---

# 3. User-approved behavior decisions

This section is a decision register. Treat it as fixed requirements unless the user explicitly changes one later.

1. **App type:** dedicated small desktop program.
2. **Target machine:** same Windows PC as the current FAST generation environment.
3. **Input length:** multiple sentences / a paragraph supported.
4. **New input while speaking:** queue it. A separate `Stop` control can interrupt.
5. **TTFA target:** do not invent a numeric target yet. Measure the real resident single-take baseline first.
6. **Normal WAV saving:** off. Do not write WAV during ordinary listening.
7. **Metrics visible:** show READY/state, TTFA, phrase synthesis time, audio length, phrase RTF, average RTF.
8. **Startup:** load Luna automatically on program launch.
9. **Audio device:** Windows default output only.
10. **Speak controls:** both `Ctrl+Enter` and `Speak` button.
11. **UI framework:** Python Tkinter.
12. **FAST synthesis:** preserve current FAST synthesis logic/quality/parameters in v1.
13. **Existing FAST code:** limited safe refactor to expose shared functions is allowed; arbitrary rewrite is not.
14. **Issue analysis:** allowed to pause continuation; normal speech must not pay the cost of deep analysis.
15. **Issue phrase selection:** show recent 3 phrases and let user choose.
16. **Issue note:** user can enter a short listening note.
17. **After issue analysis:** remain paused until user presses `Continue`.
18. **Pronunciation issues:** select problem word + enter `how it sounded` + `desired pronunciation` + note.
19. **Codex handoff:** both save issue files and provide `Copy Codex Request`.
20. **Retest:** dedicated `Retest` action.
21. **Listening modes:** both manual input and batch test mode.
22. **Batch sentence parsing:** newline first; within a line also split by sentence-ending punctuation.
23. **Rule update:** default `Reload Rules`, with quick fallback to full worker restart.
24. **Full restart:** keep UI/session alive; restart only Luna worker/model.
25. **Before/after listening:** separate `Listen Previous` / `Listen Retest` buttons; no forced automatic A/B playback.
26. **After fixing a batch issue:** restart listening from the beginning of the problem sentence, not from the next phrase.
27. **Issue history:** keep multiple revisions under the same issue ID until resolved.
28. **Codex integration:** v1 copies a complete request; user pastes it into Codex manually.
29. **Batch progress:** auto-save test list and current position; resume after app restart.
30. **Batch pass:** automatic PASS if a sentence finishes with no issue; user can pause any time.
31. **Pause behavior:** finish the currently playing phrase, then stop before the next phrase.
32. **Replay:** both replay last phrase and replay current sentence; replay cached audio, do not regenerate.
33. **Batch source:** paste text or import `.txt` / `.md`.
34. **Issue storage:** project-local `fast_speaker/issues/` unless S00 repo conventions require an equivalent safe path.
35. **Session naming:** auto timestamp name, user may edit.
36. **Crash recovery:** recover last test/session state after abnormal exit.
37. **Codex request detail:** full reproduction/fix prompt, not a short note.
38. **v1 acceptance:** features work + FAST/production regression protected + TTFA/RTF measured + end-to-end listening/issue/retest/recovery passes.

---

# 4. Core architecture

## 4.1 Required process model

Recommended v1 architecture:

```text
Tkinter UI Process
  ├─ Manual/Batch input controller
  ├─ Session state / issue UI
  ├─ Metrics renderer
  ├─ Worker command queue
  └─ Audio playback controller / audio queue
             │
             │ IPC
             ▼
Resident Luna Worker Process
  ├─ Chatterbox V3 loaded once
  ├─ Candidate B loaded/prepared once
  ├─ Current FAST phrase splitter adapter
  ├─ Current FAST single-take synth adapter
  ├─ Current FAST post-process adapter
  └─ returns in-memory PCM + metadata
```

A **separate worker process** is preferred over running TTS inside the Tkinter process because:

- Tkinter must remain responsive during 60-second startup loading and inference.
- The model must be restartable without destroying the UI/session.
- A hard worker failure should not destroy test progress.
- `Full Worker Restart` becomes a clean, deterministic operation.

Do not call heavy TTS inference from the Tkinter event thread.

## 4.2 Logical module boundaries

S00 must map these logical roles to actual repo paths. Do not blindly create these exact filenames if repo conventions differ.

```text
FAST Speaker UI
FAST Speaker controller/state machine
Resident Luna worker
FAST adapter/core
Audio sink/queue
Session persistence
Issue capture/reporting
Rule reload manager
Tests/benchmarks
```

The FAST adapter/core should expose the minimum safe surface needed by the app, e.g. conceptually:

```text
initialize_luna_once()
split_fast_text(text)
synthesize_fast_phrase(phrase, seed/context)
postprocess_fast_pcm(audio)
reload_fast_test_rules()
```

Exact names must follow existing code style.

## 4.3 Production isolation

The app must not route ordinary FAST Speaker requests through the production best-of-N loop.

The production pipeline remains intact and callable exactly as before.

If safe shared-function extraction is required:

- minimize the diff,
- preserve current public production entrypoint,
- add regression tests before changing the shared path,
- do not change outputs or parameters,
- do not change rule semantics during v1.

If S00 finds that extraction would require risky architecture changes, stop and return `BLOCKED_ARCHITECTURE_CHANGE` instead of improvising.

---

# 5. Speech critical path

## 5.1 Normal warm-state flow

After app status is `READY`:

```text
User presses Ctrl+Enter / Speak
  ↓
Capture input timestamp T0
  ↓
Parse sentences and current Luna FAST phrases
  ↓
Submit Phrase 1 to resident worker
  ↓
Worker returns PCM in memory
  ↓
Immediately queue PCM to Windows default speaker
  ↓
First non-silent sample handed to audio callback = T1
  ↓
TTFA = T1 - T0
  ↓
While Phrase 1 is playing, synthesize Phrase 2
  ↓
Queue Phrase 2
  ↓
Continue
```

The app must not wait for:

- the whole paragraph,
- the whole sentence,
- WAV file writing,
- issue analysis,
- production prosody gating,
- a full report,

before beginning playback.

## 5.2 No normal disk I/O for audio

Normal speech path:

```text
TTS tensor/array -> in-memory PCM -> audio queue -> Windows default output
```

Do not save normal speech to WAV and reopen it for playback.

## 5.3 No extra quality analysis on the normal critical path

v1 is explicitly preserving the current FAST behavior. Do not add pre-playback pitch/tail/prosody analysis that delays audio.

Deep analysis is allowed **after the user marks an issue**, when the listening flow is intentionally paused.

---

# 6. Realistic Stop / Pause / Issue semantics

This section is mandatory. Do not implement impossible cancellation behavior.

## 6.1 Stop

`Stop` means:

- speaker playback stops immediately,
- queued audio is cleared,
- queued future text is cleared for the current run,
- a new generation/session token is issued,
- any in-flight Chatterbox call that cannot be safely preempted may finish internally,
- but its result is marked stale and **must never be played**,
- app returns to input-ready state when worker is usable.

Do **not** kill the worker for every Stop unless the underlying engine is genuinely wedged.

## 6.2 Pause

`Pause` means:

- let the currently playing phrase finish,
- do not play the next phrase,
- do not auto-PASS the sentence,
- preserve current sentence/phrase context,
- remain paused until user action.

If the next phrase was already being synthesized, it may complete in memory, but it must not be played while paused.

## 6.3 Issue Mark

When `Mark Issue` is pressed:

1. Enter `ISSUE_PAUSE_PENDING`.
2. Let current phrase finish.
3. Do not continue to the next spoken phrase.
4. Present the most recent 3 phrases.
5. User selects the problematic phrase.
6. Capture issue metadata and issue-only audio evidence.
7. Run allowed analysis while speech remains paused.
8. Generate MD/JSON/Codex request.
9. Stay paused after analysis.
10. User chooses `Continue`, `Retest`, replay, or other next action.

This intentionally sacrifices throughput only after an issue is detected.

---

# 7. UI specification

## 7.1 Main window

Recommended layout:

```text
┌──────────────────────────────────────────────────────────┐
│ Luna FAST Speaker v1                    [LOADING/READY]  │
├──────────────────────────────────────────────────────────┤
│ Mode: (● Manual) (○ Batch)                              │
│ Session: [20260825_0654________________]                 │
├──────────────────────────────────────────────────────────┤
│ Input / batch text                                      │
│ [                                                      ]│
│ [                                                      ]│
│ [                                                      ]│
│ [ Import TXT/MD ]                                       │
├──────────────────────────────────────────────────────────┤
│ [Speak] [Pause] [Continue] [Stop] [Mark Issue]          │
│ [Replay Last Phrase] [Replay Current Sentence]          │
├──────────────────────────────────────────────────────────┤
│ Current sentence: ...                                   │
│ Current phrase: ...                                     │
│ Batch: 128 / 1000   PASS 121   ISSUE 6   PENDING 873    │
├──────────────────────────────────────────────────────────┤
│ TTFA: ...   Synth: ...   Audio: ...   RTF: ...          │
│ Avg RTF: ...  Worker: READY  Queue: ...                 │
├──────────────────────────────────────────────────────────┤
│ [Reload Rules] [Restart Luna Worker]                    │
└──────────────────────────────────────────────────────────┘
```

Exact visual styling is not important in v1. Responsiveness and state clarity are important.

## 7.2 Status states

At minimum expose:

- `STARTING`
- `LOADING_MODEL`
- `READY`
- `GENERATING`
- `PLAYING`
- `PAUSE_PENDING`
- `PAUSED`
- `ISSUE_ANALYZING`
- `RELOADING_RULES`
- `RESTARTING_WORKER`
- `ERROR`

Avoid ambiguous UI states.

## 7.3 Controls

### Speak
- Same behavior as `Ctrl+Enter`.
- Disabled until worker is `READY`.

### Pause
- Phrase-boundary pause.

### Continue
- Resume from preserved context.
- After issue resolution in batch mode, follow section 12 rules.

### Stop
- Immediate speaker stop and stale-result invalidation.

### Mark Issue
- Trigger issue pause/selection flow.

### Replay Last Phrase
- Play cached PCM from last phrase.
- No regeneration.

### Replay Current Sentence
- Play cached PCM segments from current sentence from the beginning.
- No regeneration.

### Reload Rules
- See section 14.

### Restart Luna Worker
- UI remains alive; session data remains alive.
- Worker/model restarts from zero.

---

# 8. Manual input mode

- Accept multi-sentence/paragraph text.
- `Enter` creates newline.
- `Ctrl+Enter` starts speaking.
- New submissions while speaking are appended to a pending text queue.
- `Stop` clears the current run’s pending queue.
- Phrase splitting must use the current FAST/Luna rules discovered in S00.

---

# 9. Batch test mode

## 9.1 Input sources

- Paste text
- Import `.txt`
- Import `.md`

No OCR, DOCX, PDF, web, or clipboard monitoring in v1.

## 9.2 Sentence parsing

Rule:

1. Newline is a high-priority test-item boundary.
2. If one line contains multiple sentences, split further on sentence-ending punctuation supported by the existing Korean text handling.
3. Preserve source order.
4. Preserve the original source string for issue reports.

Do not silently rewrite test text.

## 9.3 Batch state per sentence

At minimum:

- `PENDING`
- `PLAYING`
- `PASS`
- `ISSUE`
- `PAUSED`
- `RETEST_PENDING`

## 9.4 Automatic pass

If a sentence completes playback and the user did not pause or mark an issue:

- mark `PASS`,
- persist state atomically,
- advance to next sentence.

## 9.5 Issue flow in batch

If an issue is captured:

- mark sentence `ISSUE`,
- stay paused after analysis,
- do not auto-advance.

After Codex modifies rules and user chooses `Retest`:

- retest the problem sentence,
- after user accepts the fix, resume batch **from the beginning of that same problem sentence** once more for context validation,
- only after that context replay completes cleanly may it be marked PASS and advance.

This requirement is intentional.

---

# 10. Audio caching rules

## 10.1 Normal audio

Do not save to disk.

Keep enough PCM in RAM to support:

- recent 3 phrase selection,
- replay last phrase,
- replay current sentence.

Recommended minimum:

- all phrase PCM for the current sentence,
- at least previous 3 phrase PCM/metadata across the immediate listening context.

Bound memory usage. Evict old normal audio after it is no longer needed.

## 10.2 Issue audio

When an issue is committed, persist the selected original phrase WAV.

Retest versions may also be persisted inside that issue’s revision directory because the user needs reproducible before/after comparison.

Normal non-issue audio remains unsaved.

---

# 11. Issue capture and classification

## 11.1 Issue categories

Use at least:

- `PRONUNCIATION`
- `INTONATION`
- `PHRASE_SPLIT`
- `PACE_BREATH`
- `OTHER`

## 11.2 Recent 3 phrase selector

Show:

- phrase text,
- phrase index/id,
- sentence context,
- replay button for each candidate if convenient.

The user chooses exactly one primary problem phrase.

## 11.3 Common fields

Store:

- issue ID
- session ID/name
- created timestamp
- source mode: manual/batch
- batch item index if applicable
- original full input
- current sentence
- full phrase split for current sentence
- recent 3 phrase context
- selected problem phrase
- phrase index/id
- phrase class if available
- seed actually used
- Luna engine/reference/config snapshot
- current code revision / git commit if available
- current rule revision identifier if available
- phrase synth time
- phrase audio duration
- phrase RTF
- warm TTFA for the sentence/request if available
- user listening note
- status
- linked audio evidence paths
- revision history

## 11.4 Pronunciation-specific fields

If category = `PRONUNCIATION`, require:

- `problem_word`
- `heard_as`
- `desired_pronunciation`
- optional additional note

Do not automatically assume every pronunciation error requires a global respelling rule.

The Codex request should ask Codex to distinguish:

- deterministic/repeatable lexical pronunciation defect,
- context-sensitive split/phonetic defect,
- one-off synthesis instability.

Only repeated/deterministic evidence should justify a global rule change.

---

# 12. Issue storage and revision history

Preferred logical location:

```text
fast_speaker/
  issues/
    <SESSION_ID>/
      ISSUE-0001/
        issue.json
        issue.md
        codex_request.md
        original_problem_phrase.wav
        revisions/
          R001/
            retest.wav
            revision.json
          R002/
            retest.wav
            revision.json
```

If repo conventions require another safe app-data location, S00 must propose it and record the mapping before implementation.

## 12.1 Issue lifecycle

Example:

```text
OPEN
  -> FIX_REQUESTED
  -> RETEST_PENDING
  -> RETESTED
  -> RESOLVED
```

If retest fails:

```text
RETESTED -> FIX_REQUESTED
```

Do not create a new issue ID for each iteration of the same defect.

## 12.2 Retest evaluation

The UI must allow the user to record:

- `IMPROVED`
- `SAME`
- `WORSE`
- `RESOLVED`

Do not infer this automatically from metrics.

---

# 13. Codex request generation

`Copy Codex Request` must produce a complete, standalone request suitable for pasting into Codex.

Required content:

1. Issue ID and summary
2. Exact source sentence and selected phrase
3. Recent phrase context
4. Issue category
5. User listening note
6. Pronunciation fields when applicable
7. Exact seed/config/reference snapshot
8. Issue WAV path
9. Reproduction instructions
10. Current FAST/production invariants
11. Relevant Luna rule-evolution requirements
12. Requested fix scope
13. Required regression tests
14. Explicit prohibition on changing engine/reference/frozen production behavior
15. Required changed-files/test-results report
16. Stop-after-current-fix instruction

### 13.1 Prosody/intonation defect prompt behavior

For intonation complaints, the Codex prompt must instruct:

- use existing Luna prosody metrics from the skill,
- compare the bad phrase numerically against accepted examples where possible,
- do not rely only on subjective guessing,
- prefer rule/class correction over manual one-off take surgery,
- do not promote experimental rule changes to production without user approval.

### 13.2 Pronunciation defect prompt behavior

For pronunciation complaints, the Codex prompt must instruct:

- reproduce with the recorded text/seed,
- inspect current respell/phrase-split behavior,
- determine whether the defect is lexical/repeated vs one-off synthesis instability,
- do not add a global respell blindly if evidence is insufficient,
- add a focused regression test for any deterministic lexical correction.

---

# 14. Rule reload and worker restart

## 14.1 Reload Rules — preferred fast path

The user wants a fast fix/retest loop without paying the ~model-load startup every time.

Design requirement:

- Model stays resident.
- Candidate B stays resident.
- Only clearly designated **hot-reloadable FAST test rules/assets** are reloaded.
- Reload must be transactional:
  1. read new rules into temporary state,
  2. validate,
  3. swap active rule snapshot only on success,
  4. retain previous working snapshot on failure.

Do not use unsafe broad `reload everything` behavior.

### 14.1.1 FAST-test rule overlay

Strongly prefer a FAST-test overlay or isolated hot-reloadable rule module rather than direct uncontrolled edits to frozen production rule files.

The initial overlay must produce **no behavior change** from current FAST.

Experimental fixes discovered by listening QA can be tested here first. Promotion to the authoritative production rules is a separate user-approved action outside this v1 loop.

## 14.2 Restart Luna Worker — safe fallback

If:

- core Python code changed,
- hot reload failed,
- model/runtime state is suspicious,
- the user requests a clean reload,

then `Restart Luna Worker` must:

1. preserve UI,
2. preserve session/batch progress,
3. preserve issue data,
4. stop/replace worker process,
5. reload Luna + Candidate B,
6. return to `READY`,
7. allow immediate retest.

This is the fast escape hatch back to a clean state.

---

# 15. Session persistence and crash recovery

## 15.1 Session naming

Default name:

```text
YYYYMMDD_HHMMSS
```

User may edit it.

## 15.2 Persisted session content

At minimum:

- session ID/name
- mode
- source text/file path if imported
- parsed sentence list
- current sentence index
- per-sentence status
- issue links
- open issue/retest state
- aggregate counts
- app version/code revision

## 15.3 Atomic persistence

Persist state after meaningful transitions:

- batch import/parse
- sentence PASS
- issue creation/update
- retest result
- pause/stop where needed

Use atomic temp-write + replace or equivalent. Do not leave half-written JSON on crash.

## 15.4 Recovery behavior

On app restart:

- restore last recoverable session,
- do not auto-start speaking without user action,
- if crash occurred during a sentence, mark that sentence as uncertain and resume from the beginning of that sentence rather than skipping ahead.

---

# 16. Performance metrics and definitions

Do not invent a target before measurement.

## 16.1 Startup time

`Cold Ready Time`:

```text
app launch -> resident Luna worker READY
```

Record separately from speaking latency.

## 16.2 TTFA

Warm-state TTFA must be measured as:

```text
T0 = UI accepts Speak/Ctrl+Enter request while worker READY
T1 = first non-silent audio sample is handed to the active speaker stream/callback
TTFA = T1 - T0
```

Do not define TTFA as `WAV saved` or `synthesis function returned`.

## 16.3 Phrase synthesis time

```text
worker phrase synth call start -> postprocessed PCM ready
```

## 16.4 Phrase RTF

```text
RTF = phrase synthesis time / phrase audio duration
```

Interpretation:

- `< 1.0`: faster than playback duration for that phrase
- `= 1.0`: real-time rate
- `> 1.0`: slower than real-time

Display per phrase and rolling/aggregate average.

## 16.5 Continuity metric

Also record inter-phrase underrun/gap when next phrase is not ready by the time previous playback finishes. This is useful for the later true-real-time goal.

Do not alter synthesis quality in v1 to chase this number.

---

# 17. Baseline and benchmark requirements

S00/S01 must establish a reproducible baseline before refactoring.

Benchmark must include available repository examples spanning, where possible:

- short declarative sentence
- longer declarative sentence
- question
- number-containing phrase
- sentence likely to use multiple phrases
- a phrase-splitting edge case already covered by Luna rules

Prefer existing repo test fixtures/examples. If insufficient, add a small FAST Speaker benchmark text fixture without changing production behavior.

Capture:

- current FAST code revision
- engine/reference/config identity
- current cold load time
- current single-take phrase generation time if measurable
- current output audio metadata
- current phrase splitting

After extraction/refactor, compare against the baseline.

If exact bitwise audio equality is deterministic in this environment, use it. If the backend is not bitwise deterministic, do not fake equality; verify configuration identity, seed identity, phrase text, audio format/duration, and perform focused listening regression as documented.

---

# 18. Safety and regression requirements

## 18.1 Must never happen

- Production pipeline silently starts using FAST-test overlays.
- FAST Speaker silently changes Candidate B.
- FAST Speaker silently changes fixed synthesis parameters.
- Normal listening saves all audio to disk.
- UI freezes for the entire model load/inference because inference runs in Tkinter thread.
- Stop plays stale audio after a new request.
- Replay regenerates audio instead of replaying the exact cached take.
- Hot reload leaves half-applied rules active.
- Crash recovery skips the sentence that was active during crash.
- Codex auto-edits files from inside v1.

## 18.2 Existing Luna rules to preserve

The implementation must preserve the current phrase splitting and pronunciation constraints defined in the Luna skill, including known prohibitions such as:

- do not split after modifiers like `-한/-된/-진/-인`,
- do not split incorrectly after locative `-에서`,
- preserve current forced-split behavior and pauses,
- preserve current respell behavior,
- preserve existing sentence-middle and sentence-end pause rules where current FAST uses them.

Do not reinterpret those rules during v1.

---

# 19. Test strategy

## 19.1 Use a fake backend for most app tests

Create a test double/fake TTS backend that returns deterministic short PCM quickly so the app state machine can be tested without paying model load time.

Use the fake backend for:

- UI command tests
- queue tests
- Stop stale-result tests
- Pause boundary tests
- batch progress tests
- issue capture tests
- persistence/crash recovery tests
- hot reload failure tests
- worker restart tests

## 19.2 Real Luna integration tests

Use the real resident worker for focused integration tests only.

Required real tests:

1. app startup -> model READY
2. manual text -> first phrase audible
3. multiple phrases -> streaming/queued playback
4. multiple sentences -> sequencing
5. TTFA instrumentation works
6. RTF instrumentation works
7. Stop prevents stale audio playback
8. Pause finishes current phrase and blocks next
9. Mark Issue blocks next speech and saves issue-only evidence
10. Replay last phrase is identical cached audio
11. Replay current sentence uses cached audio
12. Reload Rules does not reload model
13. Worker Restart preserves UI/session and returns READY
14. Retest records a new revision under same issue
15. batch resume after app restart

## 19.3 Production regression

Run existing Luna production tests/smoke checks. FAST Speaker v1 is not complete if production behavior is accidentally changed.

---

# 20. v1 acceptance criteria

v1 is accepted only when all are true:

### Functional
- Tkinter app launches.
- Luna auto-loads into a separate resident worker.
- UI remains responsive while loading/inference occurs.
- Manual multi-sentence input works.
- Ctrl+Enter and Speak both work.
- First completed phrase is played without waiting for full input completion.
- Windows default speaker is used.
- Normal audio is not written to WAV.
- Metrics display and log correctly.
- New manual input can queue while speaking.
- Stop semantics work and stale audio cannot leak.
- Pause semantics work at phrase boundary.
- Batch paste/import works.
- Newline + sentence-punctuation parsing works.
- Batch auto-PASS works.
- Mark Issue shows recent 3 phrases.
- Pronunciation issue fields work.
- Issue WAV/MD/JSON are saved only when needed.
- Copy Codex Request produces a complete prompt.
- Retest works.
- Previous/Retest listening buttons work separately.
- Same issue ID retains revisions.
- Reload Rules works safely for supported rules.
- Worker Restart keeps UI/session alive.
- Batch/session state auto-saves and recovers after abnormal exit.

### Performance/measurement
- Cold Ready Time recorded.
- Warm TTFA recorded with the defined measurement point.
- Phrase synth time recorded.
- Phrase audio duration recorded.
- Phrase RTF recorded.
- Inter-phrase gap/underrun recorded if present.
- No extra production-style quality analysis occurs on the normal playback critical path.

### Regression
- Current FAST synthesis behavior is not intentionally changed.
- Current production entrypoint remains intact.
- Engine/reference/fixed parameters remain unchanged.
- Existing production regression tests/smoke checks pass.

### Human E2E
Perform at least one real user-style flow:

```text
Launch app
-> wait READY
-> import/paste batch
-> listen through several sentences
-> Pause/replay
-> Mark Issue
-> choose recent phrase
-> record pronunciation problem
-> issue report + WAV + Codex request created
-> simulate/edit a hot-reloadable rule
-> Reload Rules
-> Retest
-> record revision result
-> replay previous and retest separately
-> resume from beginning of issue sentence
-> advance batch
-> restart worker without closing UI
-> restart app and recover session
```

Document the result.

---

# 21. Recommended implementation stages

**Every stage must stop after completion. Do not continue automatically.**

Required terminal status:

`STAGE_COMPLETE_AWAITING_USER_APPROVAL`

If architecture change is required beyond the approved scope:

`BLOCKED_ARCHITECTURE_CHANGE`

with reason, affected files, proposed change, and why current architecture is insufficient.

## S00 — Repo audit + current FAST baseline

**Agent:** ARCHITECT  
**Model:** GPT-5.6 Sol / High

### Goals
- Read authoritative Luna skill completely.
- Locate current FAST implementation.
- Locate production pipeline and frozen inputs.
- Map model load, Candidate B conditioning, phrase split, single-take synthesis, postprocess, seed, audio write path.
- Identify existing tests and dependencies.
- Measure/record baseline where feasible.
- Propose exact physical file paths for v1 modules.
- Identify files that must remain untouched.

### Do not
- Refactor production.
- Change voice behavior.
- Start building UI.

### Deliverables
- `S00_REPO_AUDIT.md`
- baseline metrics/results
- exact path map
- approved/forbidden file list
- implementation risk list

---

## S01 — Runtime contracts + regression harness + safe FAST extraction

**Agent:** BUILDER  
**Model:** GPT-5.6 Terra / High

### Goals
- Build regression harness before refactor.
- Expose minimal callable FAST functions/adapters.
- Preserve existing current FAST output behavior.
- Preserve production entrypoint.
- Add fake backend contract for later app tests.

### Gate
- Baseline comparison passes.
- Production smoke/regression passes.
- No voice/config change.

---

## S02 — Resident Luna worker + in-memory PCM + metric instrumentation

**Agent:** BUILDER  
**Model:** GPT-5.6 Terra / High

### Goals
- Separate resident worker process.
- Auto-load model/Candidate B once.
- IPC command/result protocol.
- Phrase synthesis request/response.
- In-memory PCM return.
- Warm TTFA, synth time, duration, RTF instrumentation hooks.
- Generation/session IDs for stale-result invalidation.

### Gate
- Worker can restart cleanly.
- Repeated requests do not reload model.
- No normal WAV path required.

---

## S03 — Tkinter manual speaker + audio queue + Stop/Pause

**Agent:** BUILDER  
**Model:** GPT-5.6 Terra / Medium

### Goals
- Main UI.
- Auto-loading state.
- Manual multi-sentence input.
- Ctrl+Enter + Speak.
- Windows default output.
- audio queue/stream.
- phrase-first playback.
- Stop/Pause/Continue.
- replay last/current sentence from RAM.
- metrics display.

### Gate
- UI stays responsive.
- Stale result never plays after Stop.
- Pause waits for current phrase end.

---

## S04 — Batch mode + parser + automatic PASS + persistence

**Agent:** BUILDER  
**Model:** GPT-5.6 Terra / High

### Goals
- Paste batch.
- TXT/MD import.
- newline-first + sentence-punctuation parsing.
- sentence state machine.
- auto PASS.
- progress UI.
- atomic session persistence.
- crash recovery.

### Gate
- Fake-backend automated state tests pass.
- Real small batch smoke test passes.

---

## S05 — Issue capture + pronunciation workflow + Codex request + revision history

**Agent:** BUILDER  
**Model:** GPT-5.6 Terra / High

### Goals
- Mark Issue pause flow.
- recent 3 phrase selector.
- issue categories.
- listening note.
- pronunciation-specific fields.
- issue-only WAV evidence.
- MD + JSON report.
- full Codex request generation + clipboard copy.
- same-issue revision history.
- Retest.
- Previous/Retest listening.

### Gate
- Issue capture never allows next phrase to continue during analysis.
- Normal non-issue audio remains diskless.

---

## S06 — Safe rule reload + worker-only restart + retest/resume behavior

**Agent:** DEBUGGER / BUILDER  
**Model:** GPT-5.6 Terra / High

### Goals
- Transactional hot reload of explicitly supported FAST-test rules.
- Keep model resident on rule reload.
- Full worker restart fallback.
- Preserve UI/session across restart.
- If code change requires restart, handle clearly.
- Retest issue sentence.
- After accepted fix, resume from beginning of problem sentence.

### Gate
- Failed hot reload does not corrupt active rules.
- Worker restart recovers to READY.
- Session state is preserved.

---

## S07 — Full regression, performance benchmark, reviewer audit

**Agent:** REVIEWER  
**Model:** GPT-5.6 Sol / High

### Goals
- Verify every requirement in this handoff.
- Run production regression/smoke checks.
- Run current FAST behavior regression.
- Record Cold Ready, warm TTFA, phrase RTF, inter-phrase gaps.
- Run full human-style E2E flow.
- Inspect scope violations and forbidden changes.
- Produce release/readiness report.

### Output
- `S07_FINAL_REVIEW.md`
- explicit PASS/FAIL per acceptance criterion
- known limitations
- next-step recommendations for FAST quality improvement / true real-time work, but **do not implement v2**.

---

# 22. Stage execution rules for Codex

For each stage:

1. Read this master handoff.
2. Read Luna narration skill from start to finish.
3. Read current stage prompt.
4. Read previous approved stage reports.
5. Work only in current stage scope.
6. Run required tests.
7. If tests fail, debug within stage scope.
8. Do not start next stage.
9. Do not broaden architecture without approval.
10. End with exactly:

`STAGE_COMPLETE_AWAITING_USER_APPROVAL`

No next-stage preparation code.

---

# 23. Explicit non-goals for Codex to avoid scope creep

Do not add in v1:

- automatic Codex execution,
- speech-to-text,
- microphone capture,
- LLM chat,
- local API server,
- web server,
- Electron/Qt rewrite,
- speaker selection UI,
- waveform editor,
- spectrogram UI,
- automatic issue classification,
- automatic pronunciation correction,
- production best-of-N in FAST Speaker,
- new prosody gates on normal FAST playback,
- GPU migration,
- ONNX/OpenVINO conversion,
- quantization,
- model distillation,
- installer polish.

These may be separately scoped after v1 establishes the QA loop and real latency baseline.

---

# 24. What v1 should enable immediately after completion

The intended user workflow is:

```text
1. Launch Luna FAST Speaker.
2. Luna loads once and reaches READY.
3. Paste/import hundreds of test sentences.
4. Start batch listening.
5. Normal sentences auto-PASS and continue.
6. Hear something strange.
7. Mark Issue.
8. Choose the relevant phrase from recent 3.
9. Classify the problem.
10. For pronunciation: select word, record heard-as and desired pronunciation.
11. Save issue evidence and copy complete Codex request.
12. Paste request into Codex.
13. Codex modifies only the approved FAST-test rule/code scope.
14. Click Reload Rules; if not safe/applicable, click Restart Luna Worker.
15. Retest the same issue.
16. Listen to Previous or Retest separately as needed.
17. Mark Improved/Same/Worse/Resolved.
18. Replay problem sentence from the beginning.
19. Continue the batch.
20. Repeat until the Luna rule set is materially more robust.
```

This is the primary success definition of v1.

---

# 25. Future direction — not part of v1

After v1 establishes the measurement baseline and a large issue corpus, future work may separately investigate:

- raising first-take naturalness without increasing runtime,
- using accumulated accepted/rejected data to improve single-take success probability,
- reducing warm TTFA,
- reducing phrase RTF,
- true continuous real-time playback where generation reliably stays ahead of playback,
- LLM token streaming -> Luna phrase streaming,
- automatic Codex integration.

These are intentionally deferred until v1 gives trustworthy data.
