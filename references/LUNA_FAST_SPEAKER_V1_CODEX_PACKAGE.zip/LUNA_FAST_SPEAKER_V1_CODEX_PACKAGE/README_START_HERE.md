# START HERE — Luna FAST Speaker v1

Give Codex this package and instruct it to start with `S00` only.

Authoritative order:
1. Project `luna-narration` skill (read fully)
2. `00_LUNA_FAST_SPEAKER_V1_MASTER_HANDOFF.md`
3. `stage_plan.example.json`
4. `prompts/S00_REPO_AUDIT.md`

Do not implement S01 or later until the user explicitly approves S00.

Required end state for every completed stage:

`STAGE_COMPLETE_AWAITING_USER_APPROVAL`
