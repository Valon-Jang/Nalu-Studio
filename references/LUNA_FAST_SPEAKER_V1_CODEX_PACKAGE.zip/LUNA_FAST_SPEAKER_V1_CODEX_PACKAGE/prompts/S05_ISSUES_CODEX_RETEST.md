# S05 — Issue Capture + Pronunciation Workflow + Codex Request + Retest

You are the BUILDER agent for Luna FAST Speaker v1 Stage S05.

## Goal
Turn listening defects into reproducible issue packages without slowing normal speech.

## Required work
- `Mark Issue` enters issue-pause flow.
- Current phrase finishes; next spoken phrase must not continue during issue analysis.
- Show recent 3 phrases and let user select one primary issue phrase.
- Issue categories:
  - PRONUNCIATION
  - INTONATION
  - PHRASE_SPLIT
  - PACE_BREATH
  - OTHER
- Common listening note.
- For PRONUNCIATION require:
  - problem word
  - heard as
  - desired pronunciation
  - optional note
- Save issue-only original phrase WAV.
- Save issue JSON + MD.
- Save complete `codex_request.md`.
- `Copy Codex Request` copies full standalone prompt to Windows clipboard.
- Keep exact seed/config/reference/code revision metadata when available.
- Use existing Luna analysis metrics only where already defined/available; issue analysis may run while paused.
- Same issue ID accumulates revision history.
- `Retest` creates a new revision.
- `Listen Previous` and `Listen Retest` are separate controls.
- Retest evaluation values: IMPROVED/SAME/WORSE/RESOLVED.
- Never infer resolution automatically.

## Codex request requirements
Must include production invariants and prohibit engine/reference/fixed-parameter changes. For intonation, instruct numeric comparison per Luna skill. For pronunciation, distinguish repeatable lexical defect vs one-off synthesis instability before global respell.

## Gate
- No next phrase is spoken during issue analysis.
- Normal non-issue audio remains unsaved.
- Issue package is self-contained enough to reproduce.

Terminate with exactly:

STAGE_COMPLETE_AWAITING_USER_APPROVAL
