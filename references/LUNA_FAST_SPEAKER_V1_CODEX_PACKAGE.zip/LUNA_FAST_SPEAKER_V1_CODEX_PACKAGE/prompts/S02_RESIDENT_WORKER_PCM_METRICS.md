# S02 — Resident Luna Worker + In-Memory PCM + Metrics

You are the BUILDER agent for Luna FAST Speaker v1 Stage S02.

## Goal
Build a restartable resident Luna worker process that loads Luna once and serves phrase synthesis requests in memory.

## Required work
- Separate worker process from future Tkinter UI.
- Worker auto-loads Chatterbox V3 and Candidate B using the approved current environment.
- Keep model/reference resident across repeated requests.
- Define IPC commands and responses.
- Return in-memory PCM + sample rate + phrase metadata; normal operation must not require WAV.
- Add request/session/generation IDs.
- Support stale-result invalidation so a stopped run cannot later play old audio.
- Instrument:
  - worker load/READY time
  - phrase synthesis start/end
  - PCM-ready timestamp
  - audio duration
  - RTF data
- Provide clean worker shutdown/restart lifecycle.

## Realism requirement
Do not claim an in-flight Chatterbox call can be preempted unless the backend actually supports safe cancellation. A stale in-flight result may finish internally but must be discardable.

## Gate
- Multiple phrase requests do not reload model.
- Worker restart is clean.
- In-memory PCM is returned.
- No normal WAV dependency.
- Existing FAST/production regression remains green.

Terminate with exactly:

STAGE_COMPLETE_AWAITING_USER_APPROVAL
