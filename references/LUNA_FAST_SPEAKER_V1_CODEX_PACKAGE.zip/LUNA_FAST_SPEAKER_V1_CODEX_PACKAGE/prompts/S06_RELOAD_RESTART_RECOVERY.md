# S06 — Safe Rule Reload + Worker Restart + Retest Resume

You are the DEBUGGER/BUILDER agent for Luna FAST Speaker v1 Stage S06.

## Goal
Make the human QA -> Codex fix -> immediate retest loop fast and safe.

## Required work
- Implement `Reload Rules` for explicitly supported hot-reloadable FAST-test rules/assets only.
- Prefer an isolated FAST-test overlay or narrowly reloadable module.
- Initial overlay must cause no behavior change.
- Transactional reload:
  - load temp
  - validate
  - swap only on success
  - keep old active state on failure
- Reload Rules must not reload Chatterbox/model/reference.
- Implement `Restart Luna Worker` fallback:
  - UI remains alive
  - session/batch progress remains alive
  - issue state remains alive
  - worker/model starts clean and returns READY
- Clearly signal when a code change requires worker restart instead of rule reload.
- Retest same issue sentence.
- After fix is accepted, resume batch from beginning of the problem sentence for context validation.
- Ensure failed reload/restart cannot corrupt persisted session.

## Gate
- Hot reload failure leaves old working rules active.
- Worker restart preserves UI/session.
- Retest/resume behavior matches master handoff.

Terminate with exactly:

STAGE_COMPLETE_AWAITING_USER_APPROVAL
