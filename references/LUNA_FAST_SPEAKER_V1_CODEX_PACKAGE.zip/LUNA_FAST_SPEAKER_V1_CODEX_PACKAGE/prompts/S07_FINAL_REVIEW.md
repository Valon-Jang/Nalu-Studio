# S07 — Final Regression + Performance + Reviewer Audit

You are the REVIEWER agent for Luna FAST Speaker v1 Stage S07.

## Goal
Audit implementation against every requirement in the master handoff. Do not implement v2.

## Required work
- Build a requirement-by-requirement PASS/FAIL matrix.
- Inspect changed files for scope violations.
- Verify engine/reference/fixed parameters are unchanged.
- Verify production entrypoint and existing production behavior remain intact.
- Verify current FAST behavior was not intentionally changed.
- Run automated tests.
- Run focused real-Luna integration tests.
- Record:
  - cold READY time
  - warm TTFA
  - phrase synth time
  - audio duration
  - phrase/average RTF
  - inter-phrase gaps/underruns
- Verify normal speech does not write WAV.
- Verify issue-only audio/report behavior.
- Verify Stop stale-result behavior.
- Verify Pause/Continue.
- Verify batch auto-PASS.
- Verify crash recovery.
- Verify recent-3 issue selector.
- Verify pronunciation fields.
- Verify Codex request completeness.
- Verify Retest + revision history.
- Verify Reload Rules + failure rollback.
- Verify Worker Restart preserves UI/session.
- Run the full human-style E2E flow from the master handoff.

## Deliverable
`S07_FINAL_REVIEW.md` with:
- PASS/FAIL matrix
- performance table
- regression evidence
- known limitations
- blockers if any
- recommendations for later FAST quality/true-real-time work only; do not implement them.

Terminate with exactly:

STAGE_COMPLETE_AWAITING_USER_APPROVAL
