# S04 — Batch Mode + Parser + Persistence + Crash Recovery

You are the BUILDER agent for Luna FAST Speaker v1 Stage S04.

## Goal
Enable large-scale listening sessions with automatic progression and reliable resume.

## Required work
- Manual/Batch mode selection.
- Paste batch text.
- Import `.txt` and `.md`.
- Parse newline as high-priority boundary, then sentence-ending punctuation within a line.
- Preserve original text/order.
- Batch item states: PENDING/PLAYING/PASS/ISSUE/PAUSED/RETEST_PENDING or equivalent.
- Auto-PASS on clean sentence completion.
- Show current sentence, next/progress, PASS/ISSUE/PENDING counts.
- Pause prevents auto-PASS/advance.
- Session default timestamp name, editable.
- Atomic session persistence after meaningful state changes.
- Crash recovery.
- On crash during active sentence, resume from beginning of that sentence; never silently skip it.
- Do not auto-start speech after application restart; require user action after recovery.

## Testing
Use fake backend for state-machine tests and a small real-Luna smoke batch.

## Gate
- Batch progress survives normal and abnormal restart.
- Parser behavior is covered by tests.
- No normal audio files are created.

Terminate with exactly:

STAGE_COMPLETE_AWAITING_USER_APPROVAL
