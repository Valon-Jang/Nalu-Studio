# S01 — Runtime Contracts + Regression Harness + Safe FAST Extraction

You are the BUILDER agent for Luna FAST Speaker v1 Stage S01.

## Inputs
- Full `luna-narration` skill
- Master handoff
- Approved `S00_REPO_AUDIT.md`

## Goal
Create the minimum safe callable FAST runtime surface and regression harness without changing current FAST or production behavior.

## Required work
- Add tests/fixtures that capture current FAST behavior before refactor.
- Define a narrow backend interface usable by both real Luna worker and fake test backend.
- Expose/adapt existing FAST operations needed by the app:
  - initialize once
  - phrase split
  - one current-FAST phrase synthesis
  - current FAST postprocess to PCM
  - metadata/seed return
- Preserve existing production entrypoint and outputs.
- Preserve fixed Luna engine/reference/parameters.
- Add a deterministic fake backend returning known PCM for later UI/state tests.
- Document whether bitwise output regression is possible in the current backend; if not, use the strongest honest alternative specified in master handoff.

## Prohibitions
- No Tkinter UI yet.
- No model-resident process yet.
- No rule improvement.
- No new prosody gates.

## Gate
- Regression harness passes.
- Production smoke/regression passes.
- Current FAST config identity is unchanged.
- No intentional audio behavior change.

Terminate with exactly:

STAGE_COMPLETE_AWAITING_USER_APPROVAL
