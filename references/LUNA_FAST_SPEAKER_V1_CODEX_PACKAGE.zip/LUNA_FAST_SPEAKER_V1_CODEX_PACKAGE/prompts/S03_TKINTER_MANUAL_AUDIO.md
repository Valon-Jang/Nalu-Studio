# S03 — Tkinter Manual Speaker + Audio Queue + Stop/Pause

You are the BUILDER agent for Luna FAST Speaker v1 Stage S03.

## Goal
Implement the manual speaking UI and phrase-first audio playback while keeping UI responsive.

## Required work
- Tkinter main window.
- Auto-start resident Luna worker and show loading/READY state.
- Multi-line input.
- `Ctrl+Enter` + `Speak`.
- Windows default output device only.
- Persistent/open audio stream or equivalent low-overhead in-memory playback path.
- Phrase 1 plays as soon as ready; do not wait for full sentence/paragraph.
- While phrase N plays, allow synthesis of phrase N+1 when possible.
- New manual submissions while speaking go to pending queue.
- `Stop` semantics exactly as master handoff.
- `Pause` semantics exactly as master handoff.
- `Continue`.
- RAM cache for current sentence and recent phrases.
- `Replay Last Phrase` and `Replay Current Sentence` use cached PCM only.
- On-screen metrics:
  - cold READY time
  - warm TTFA
  - phrase synth time
  - audio duration
  - RTF
  - average/rolling RTF
  - queue/state
- Measure TTFA at first non-silent audio handed to the active audio callback/stream.

## Prohibitions
- No WAV save for normal speech.
- No issue system yet.
- No batch system yet.
- No quality improvement gates on critical path.

## Gate
- UI remains responsive during loading/inference.
- Stale audio cannot play after Stop.
- Pause ends current phrase then blocks next.
- Replay does not regenerate.

Terminate with exactly:

STAGE_COMPLETE_AWAITING_USER_APPROVAL
