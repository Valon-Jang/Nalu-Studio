# S00 — Repo Audit + Current FAST Baseline

You are the ARCHITECT agent for Luna FAST Speaker v1 Stage S00.

## Read first
1. Full project `luna-narration` skill.
2. `00_LUNA_FAST_SPEAKER_V1_MASTER_HANDOFF.md`.
3. Existing repo instructions (`AGENTS.md`, stage policy, etc.).

## Scope
Audit only. Do not build the UI or refactor synthesis yet.

## Required work
- Locate the exact current FAST implementation used for the user's current fast-generation flow.
- Locate the production pipeline and frozen Luna reference/parameter/prosody assets.
- Map:
  - model load
  - Candidate B/reference conditioning
  - seed path
  - phrase split
  - single-take FAST synthesis
  - postprocessing
  - WAV/disk output
  - report/metric functions already available
- Identify existing audio playback dependencies, if any.
- Identify current Python process/environment and Windows constraints.
- Identify current test coverage.
- Measure a minimal baseline where feasible without changing behavior.
- Propose exact physical module paths for FAST Speaker v1 following repo conventions.
- Produce allowed-path and forbidden-path lists for S01-S07.
- Call out any architecture conflict with the master handoff.

## Explicit prohibitions
- Do not change engine/reference/parameters.
- Do not change production phrase splitting or prosody rules.
- Do not implement next stages.
- Do not create a new TTS engine path.

## Deliverable
Write `S00_REPO_AUDIT.md` containing:
- repo map
- current FAST path
- current production path
- frozen assets
- baseline observations
- exact proposed file layout
- dependency inventory
- risk/blocker list
- allowed/forbidden paths
- recommended S01 approach

If a material architecture change is required, stop with `BLOCKED_ARCHITECTURE_CHANGE`.

Otherwise terminate with exactly:

STAGE_COMPLETE_AWAITING_USER_APPROVAL
